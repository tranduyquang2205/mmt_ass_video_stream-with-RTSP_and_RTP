# Streaming video with RTSP and RTP
### Installation
```sh
python Server.py 1025
python ClientLauncher.py localhost 1025 5008 video.mjpeg
```
![alt text](demo.png "Demo")